   @override
   public boolean onmenuitemclick(menuitem item)
   {
           switch (item.getitemid())
           {
               case r.id.item_comedy:
                   toast.maketext(this, "comedy clicked", toast.length_short).show();
                   return true;
               case r.id.item_movies:
                   toast.maketext(this, "movies clicked", toast.length_short).show();
                   return true;
               case r.id.item_music:
                   toast.maketext(this, "music clicked", toast.length_short).show();
                   return true;
           }
                   return true;
       }
   }
