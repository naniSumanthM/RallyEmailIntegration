 public void userStoryWithMultipleAttachments(string workspace, string project, string userStoryName, string userStoryDescription)
{
            //Authentication
            this.EnsureRallyIsAuthenticated();

            //UserStory Setup
            DynamicJsonObject toCreate = new DynamicJsonObject();
            toCreate[RallyField.workSpace] = workspace;
            toCreate[RallyField.project] = project;
            toCreate[RallyField.nameForWSorUSorTA] = userStoryName;
            toCreate[RallyField.description] = userStoryDescription;

            Dictionary <string, int> imageDictionary = new Dictionary <string, int>();
            Image myImage;
            string base64ImageString;
            int imageByteSize = 0;
            string myAttachmentContentRef;
            DynamicJsonObject myAttachmentContent = new DynamicJsonObject();
            DynamicJsonObject myAttachmentContainer = new DynamicJsonObject();

            string[] filePaths = Directory.GetFiles("C:\\Users\\maddirsh\\Desktop\\RallyAttachments");

            foreach (string filePath in filePaths)
            {
                myImage = Image.FromFile(filePath); //alternative to .x files
                base64ImageString = imageToBase64(myImage, System.Drawing.Imaging.ImageFormat.Png);
                imageByteSize = Convert.FromBase64String(base64ImageString).Length;
                imageDictionary.Add(base64ImageString, imageByteSize);
                Console.WriteLine(filePath);
            }

            //Create US - this line creates the userstory
            CreateResult createUserStory = _api.Create(RallyField.hierarchicalRequirement, toCreate);

            foreach (KeyValuePair<string, int> imagePair in imageDictionary)
            {
                try
                {
                    myAttachmentContent[RallyField.content] = imagePair.Key;

                    CreateResult myAttachmentContentCreateResult = _api.Create(RallyField.attachmentContent, myAttachmentContent);
                    myAttachmentContentRef = myAttachmentContentCreateResult.Reference;

                    myAttachmentContainer[RallyField.artifact] = createUserStory.Reference; //say this attachment is linked to this user story
                    myAttachmentContainer[RallyField.content] = myAttachmentContentRef; //passing the reference of the attachment to the container
                    myAttachmentContainer[RallyField.nameForWSorUSorTA] = "AttachmentFromREST.png"; //changing the file name of the attachment
                    myAttachmentContainer[RallyField.description] = "Email Attachment";
                    myAttachmentContainer[RallyField.contentType] = "image/png"; //contentType
                    myAttachmentContainer[RallyField.size] = imagePair.Value;

                    //create & associate the attachment
                    CreateResult myAttachmentCreateResult = _api.Create(RallyField.attachment, myAttachmentContainer);
                    Console.WriteLine("Created User Story: " + createUserStory.Reference);

                }
                catch (WebException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
}
