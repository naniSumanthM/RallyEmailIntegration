import java.io.*;

public class ProductWriter
{
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        String id, name, description;
        double cost;
        boolean doneInputting = false;
        String fileName;
        PrintWriter pw;
        ArrayList<String> products = new ArrayList<>();

        do
        {
            System.out.print("Please enter product id: ");
            id = console.nextLine();

            System.out.println("Please enter product name: ");
            name = console.nextLine();

            System.out.println("Please enter product description: ");
            description = console.nextLine();

            System.out.println("Please enter product cost: ");
            cost = console.nextDouble();

            console.nextLine(); //what does this line do

            products.add(id + ",    " + name + ",    " + description + ",    " + cost);

            doneInputting = safeInput.getYNConfirmDialog("Are you done inserting product data?");
        }
        while(!doneInputting);

        try
        {
            System.out.println("Enter file name: ");
            fileName= console.nextLine();
            pw = new PrintWriter(fileName); //printtWriter prints data onto a text file

            for (String product: products)
            {
                pw.println(product);
            }
                pw.close();
         }
        catch(FileNotFoundException ex)
            {
                System.out.println("File cannot be opened to write!");
                System.exit(0);
            }

        catch(IOException ex)
            {
                ex.printStackTrace();
                    System.exit(0);
            }

    }
}
